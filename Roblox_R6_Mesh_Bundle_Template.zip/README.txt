ROBLOX R6 MESH BUNDLE TEMPLATE

This package contains the mesh assembly template only. The player-highlight feature and its scripts have been removed.

The supplied archive contains five separate Roblox .mesh files: torso, left/right arms, and left/right legs. There is no head mesh, and these files are not a ready-made R6 rig.

SETUP
1. Upload/import each .mesh file as a Roblox mesh asset using Roblox Studio.
2. Copy the resulting asset IDs into ASSET_IDS in BuildFemboyLongJohnR6.server.lua.
3. Run the builder Script in ServerScriptService in Studio.
4. Preview the assembly and adjust each MeshPart's size and position to fit the source geometry.

IMPORTANT
- The builder creates a welded visual assembly with an R6 Humanoid marker; it is not a fully animation-ready character rig.
- For a playable morph, attach the mesh visuals to a standard R6 rig using Motor6D joints (RootJoint, Neck, shoulders, hips), or use the meshes as geometry for the actual R6 body parts.
- The mesh asset IDs are placeholders until you upload the meshes.
