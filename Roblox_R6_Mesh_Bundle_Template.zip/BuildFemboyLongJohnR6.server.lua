-- ServerScriptService/BuildFemboyLongJohnR6.server.lua
-- TEMPLATE: upload each supplied .mesh file as a Roblox MeshPart asset first,
-- then paste its asset ID below. This builds a welded display/model template.
-- The archive has arms, legs and torso, but NO head mesh. A standard R6 head is added.
-- NOTE: This is a visual R6-style bundle; for a playable Humanoid rig, use the
-- standard R6 body parts/joints and attach these MeshParts as visuals.

local ASSET_IDS = {
    Torso = "rbxassetid://PASTE_TORSO_MESH_ID",
    LeftArm = "rbxassetid://PASTE_LEFTARM_MESH_ID",
    RightArm = "rbxassetid://PASTE_RIGHTARM_MESH_ID",
    LeftLeg = "rbxassetid://PASTE_LEFTLEG_MESH_ID",
    RightLeg = "rbxassetid://PASTE_RIGHTLEG_MESH_ID",
}

local old = workspace:FindFirstChild("FemboyLongJohn_R6_Bundle")
if old then old:Destroy() end

local model = Instance.new("Model")
model.Name = "FemboyLongJohn_R6_Bundle"
model.Parent = workspace

local function makeMeshPart(name, assetId, size, position)
    assert(not string.find(assetId, "PASTE_"), "Set the uploaded mesh asset IDs in ASSET_IDS first.")
    local part = Instance.new("MeshPart")
    part.Name = name
    part.MeshId = assetId
    part.Size = size
    part.Position = position
    part.Anchored = false
    part.CanCollide = false
    part.Parent = model
    return part
end

-- Approximate R6 proportions/positions. Adjust offsets after previewing the imported meshes.
local origin = Vector3.new(0, 5, 0)
local torso = makeMeshPart("Torso", ASSET_IDS.Torso, Vector3.new(2, 2, 1), origin)
local leftArm = makeMeshPart("Left Arm", ASSET_IDS.LeftArm, Vector3.new(1, 2, 1), origin + Vector3.new(-1.5, 0, 0))
local rightArm = makeMeshPart("Right Arm", ASSET_IDS.RightArm, Vector3.new(1, 2, 1), origin + Vector3.new(1.5, 0, 0))
local leftLeg = makeMeshPart("Left Leg", ASSET_IDS.LeftLeg, Vector3.new(1, 2, 1), origin + Vector3.new(-0.5, -2, 0))
local rightLeg = makeMeshPart("Right Leg", ASSET_IDS.RightLeg, Vector3.new(1, 2, 1), origin + Vector3.new(0.5, -2, 0))

local head = Instance.new("Part")
head.Name = "Head"
head.Shape = Enum.PartType.Ball
head.Size = Vector3.new(2, 1, 1)
head.Position = origin + Vector3.new(0, 1.5, 0)
head.Anchored = false
head.CanCollide = false
head.Parent = model

local function weldTo(part, root)
    local weld = Instance.new("WeldConstraint")
    weld.Part0 = root
    weld.Part1 = part
    weld.Parent = root
end

for _, part in ipairs({leftArm, rightArm, leftLeg, rightLeg, head}) do
    weldTo(part, torso)
end

local root = Instance.new("Part")
root.Name = "HumanoidRootPart"
root.Size = Vector3.new(2, 2, 1)
root.Transparency = 1
root.CanCollide = false
root.Anchored = false
root.Position = origin
root.Parent = model
weldTo(root, torso)

local humanoid = Instance.new("Humanoid")
humanoid.RigType = Enum.HumanoidRigType.R6
humanoid.Parent = model
model.PrimaryPart = root
